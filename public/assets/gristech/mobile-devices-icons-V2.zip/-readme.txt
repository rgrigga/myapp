This mobile devices icon set was made with love by loris grilletwww.loriskumo.com
@loriskumo
dribbble.com/loriskumo

Attribution-ShareAlike 3.0 Unported (CC BY-SA 3.0)
Feel free to use this work for any personal or commercial projects.
Make awesomely beautiful stuff with it please!

V 2.0, November 2nd 2012